import Clicker from "./Clicker";
import "./App.css";

function App() {
  return (
    <div>
      <Clicker />
      <Clicker />
    </div>
  );
}

export default App;
